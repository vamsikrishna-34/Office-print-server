'use strict';
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const cfg = require('./lib/config');
const { HttpError } = require('./lib/errors');
const { detectType } = require('./lib/filetype');
const { parseMultipart } = require('./lib/multipart');
const { validateOptions, summary, SIDES, PAPERS, ORIENTATIONS } = require('./lib/options');
const { createLimiter } = require('./lib/ratelimit');
const { openStore } = require('./lib/store');
const { createQueue } = require('./lib/queue');
const { findSoffice } = require('./lib/docx');
const { createPrinter } = require('./printers');

const log = (m) => console.log(`${new Date().toISOString().slice(11, 19)} ${m}`);
process.on('uncaughtException', (e) => log(`UNCAUGHT ${e.stack || e}`));
process.on('unhandledRejection', (e) => log(`UNHANDLED ${e && e.stack || e}`));

const store = openStore(cfg);
const recovered = store.recover();
const printer = createPrinter(cfg);
const queue = createQueue({ cfg, store, printer, log });
const docxEnabled = !!findSoffice(cfg);
const page = fs.readFileSync(path.join(__dirname, 'public', 'index.html'));

const general = createLimiter(cfg.rateLimitPerMin);
const uploads = createLimiter(cfg.uploadLimitPerMin);
const pinFails = createLimiter(10);
const hash = (s) => crypto.createHash('sha256').update(s).digest();

const SECURITY = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'",
};
function send(res, status, body, headers = {}) {
  const isJson = typeof body !== 'string' && !Buffer.isBuffer(body);
  const data = isJson ? JSON.stringify(body) : body;
  res.writeHead(status, { 'Content-Type': isJson ? 'application/json; charset=utf-8' : 'text/html; charset=utf-8', 'Cache-Control': 'no-store', ...SECURITY, ...headers });
  res.end(data);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    if (Number(req.headers['content-length']) > limit) return reject(new HttpError(413, tooBig()));
    const chunks = []; let n = 0; let done = false;
    req.on('data', (c) => {
      if (done) return;
      n += c.length;
      if (n > limit) { done = true; reject(new HttpError(413, tooBig())); return; }
      chunks.push(c);
    });
    req.on('end', () => { if (!done) { done = true; resolve(Buffer.concat(chunks)); } });
    req.on('error', (e) => { if (!done) { done = true; reject(e); } });
    req.on('aborted', () => { if (!done) { done = true; reject(new HttpError(400, 'Upload was interrupted.')); } });
  });
}
const tooBig = () => `File is too large. The limit is ${cfg.maxUploadMb} MB.`;

const jobView = (r) => ({
  id: r.id, status: r.status, reason: r.reason, name: r.display_name, owner: r.owner, type: r.file_type, size: r.size,
  options: JSON.parse(r.options), summary: summary(JSON.parse(r.options)), createdAt: r.created_at, finishedAt: r.finished_at,
});

function displayName(raw) {
  const base = String(raw || '').replace(/[\u0000-\u001f\u007f]/g, ' ').split(/[\\/]/).pop().trim();
  return Array.from(base || 'file').slice(0, 80).join('');
}

function authorize(req, ip) {
  if (!cfg.pin) return;
  if (pinFails.blocked(ip)) throw new HttpError(429, 'Too many wrong PIN attempts. Wait a minute and try again.');
  const given = req.headers['x-pin'];
  if (given === undefined) throw new HttpError(401, 'Enter the access PIN.');
  if (!crypto.timingSafeEqual(hash(String(given)), hash(cfg.pin))) { pinFails.hit(ip); throw new HttpError(401, 'Wrong PIN.'); }
}

async function handle(req, res) {
  const ip = req.socket.remoteAddress || 'unknown';
  const url = new URL(req.url, 'http://x');
  const route = `${req.method} ${url.pathname}`;

  if (route === 'GET /' || route === 'GET /index.html') return send(res, 200, page);
  if (route === 'GET /favicon.ico') return send(res, 204, '');

  const wait = general.hit(ip);
  if (wait) throw new HttpError(429, `Too many requests. Wait ${wait} seconds.`);

  if (route === 'GET /api/config') {
    return send(res, 200, { pinRequired: !!cfg.pin, maxMb: cfg.maxUploadMb, maxCopies: cfg.maxCopies, docx: docxEnabled, testMode: cfg.testMode,
      sides: SIDES, papers: PAPERS, orientations: ORIENTATIONS });
  }
  if (!url.pathname.startsWith('/api/')) throw new HttpError(404, 'Not found.');
  authorize(req, ip);

  if (route === 'GET /api/state') {
    const st = await printer.status();
    return send(res, 200, { printer: { ...st, waiting: store.waitingCount(), printing: store.printingCount() }, jobs: store.recent(30).map(jobView) });
  }

  if (route === 'POST /api/jobs') {
    const w = uploads.hit(ip);
    if (w) throw new HttpError(429, `Too many uploads. Wait ${w} seconds.`);
    if (store.waitingCount() >= cfg.maxWaiting) throw new HttpError(429, 'The queue is full. Try again in a few minutes.');
    if (!/^multipart\/form-data/i.test(req.headers['content-type'] || '')) throw new HttpError(400, 'Send the file as a form upload.');
    const body = await readBody(req, cfg.maxUploadBytes + 1024 * 1024);
    const { fields, file } = parseMultipart(body, req.headers['content-type']);
    if (!file) throw new HttpError(400, 'No file received. Choose a file first.');
    if (!file.data.length) throw new HttpError(400, 'The file is empty.');
    if (file.data.length > cfg.maxUploadBytes) throw new HttpError(413, tooBig());
    const type = detectType(file.data);
    if (type === 'heic') throw new HttpError(415, 'HEIC photos are not supported. Choose the photo as JPG, or change the camera format to "Most Compatible".');
    if (type === 'doc') throw new HttpError(415, 'Old .doc files are not supported. Save the file as DOCX or PDF.');
    if (type === 'docx' && !docxEnabled) throw new HttpError(415, 'Word files are not available on this server (LibreOffice is not installed). Save the file as PDF.');
    if (!type) throw new HttpError(415, `Unsupported file type. Send a PDF, PNG, JPG${docxEnabled ? ' or DOCX' : ''}. The file name does not matter, only what is inside.`);
    const options = validateOptions(fields, cfg, type);
    const stored = `${crypto.randomUUID()}.${type === 'jpg' ? 'jpg' : type}`;
    fs.writeFileSync(path.join(cfg.uploadDir, stored), file.data, { flag: 'wx' });
    const id = store.insert({ displayName: displayName(file.filename), owner: options.name, fileType: type, size: file.data.length, options, file: stored });
    log(`job ${id} queued (${type}, ${file.data.length} bytes) from ${ip}`);
    queue.wake();
    return send(res, 201, { job: jobView(store.get(id)) });
  }

  const cancel = /^POST \/api\/jobs\/(\d{1,12})\/cancel$/.exec(route);
  if (cancel) {
    const id = Number(cancel[1]);
    const row = store.get(id);
    if (!row) throw new HttpError(404, 'That job no longer exists.');
    if (row.file && store.cancel(id)) { fs.rmSync(path.join(cfg.uploadDir, row.file), { force: true }); log(`job ${id} cancelled`); return send(res, 200, { ok: true }); }
    throw new HttpError(409, row.status === 'printing' ? 'This job has already started printing and cannot be cancelled.' : `This job is already ${row.status}.`);
  }
  throw new HttpError(404, 'Not found.');
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((e) => {
    const status = e instanceof HttpError ? e.status : 500;
    if (status === 500) log(`ERROR ${e.stack || e}`);
    if (res.headersSent) return res.destroy();
    send(res, status, { error: e instanceof HttpError ? e.message : 'Something went wrong on the server. Try again.' });
    // Keep the connection open so the client can still read the error while it finishes sending.
    // Unread upload data is thrown away, and the connection is cut if it is absurdly large.
    let n = 0; req.on('data', (c) => { n += c.length; if (n > cfg.maxUploadBytes * 4) req.destroy(); }); req.resume();
  });
});
server.requestTimeout = 120000;
server.headersTimeout = 20000;
server.keepAliveTimeout = 5000;
server.on('clientError', (e, socket) => { if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); });

server.listen(cfg.port, cfg.host, () => {
  const port = server.address().port;
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal && !i.address.startsWith('169.254.')).map((i) => i.address);
  console.log('');
  console.log(`Print server running. Mode: ${printer.name}`);
  console.log('Open this address on a phone or laptop on the same Wi-Fi:');
  for (const ip of ips.length ? ips : ['localhost']) console.log(`    http://${ip}:${port}`);
  console.log(`Limits: ${cfg.maxUploadMb} MB per file, up to ${cfg.maxCopies} copies, ${cfg.maxWaiting} waiting jobs.`);
  if (!cfg.pin) console.log('\n*** WARNING: no access PIN is set. Anyone on the network can print. Set PIN=1234 (any value) to protect it. ***\n');
  for (const w of printer.warnings()) console.log(`*** WARNING: ${w} ***`);
  if (recovered.interrupted || recovered.lost || recovered.waiting) log(`Restart recovery: ${recovered.waiting} waiting job(s) resume, ${recovered.interrupted} interrupted job(s) marked failed, ${recovered.lost} lost, ${recovered.orphans} stray file(s) removed.`);
  queue.wake();
});
server.on('error', (e) => { console.error(e.code === 'EADDRINUSE' ? `Port ${cfg.port} is already in use. Set PORT to another number.` : e.message); process.exit(1); });

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { log(`${sig}: stopping`); server.close(); setTimeout(() => process.exit(0), 200).unref(); });
