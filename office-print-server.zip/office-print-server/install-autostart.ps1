# Run once in PowerShell as Administrator, from this folder:  powershell -ExecutionPolicy Bypass -File .\install-autostart.ps1
# Starts the print server whenever the user logs in, restarts it if it crashes, and opens the firewall port.
param([int]$Port = 3000, [string]$TaskName = "OfficePrintServer")
$ErrorActionPreference = "Stop"
$dir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$node = (Get-Command node -ErrorAction Stop).Source
$action   = New-ScheduledTaskAction -Execute $node -Argument "server.js" -WorkingDirectory $dir
$trigger  = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet -RestartCount 99 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
if (-not (Get-NetFirewallRule -DisplayName "Office Print Server" -ErrorAction SilentlyContinue)) {
  New-NetFirewallRule -DisplayName "Office Print Server" -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Private,Domain | Out-Null
}
Write-Host "Done. The print server will start at your next log-in. Start it now with:  Start-ScheduledTask -TaskName $TaskName"
Write-Host "Remove it with:  Unregister-ScheduledTask -TaskName $TaskName -Confirm:`$false"
