'use strict';
// End-to-end checks against a real running server in test mode.  Run: npm test
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');

const TINY_JPG = Buffer.from('/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAA0JCgsKCA0LCgsODg0PEyAVExISEyccHhcgLikxMC4pLSwzOko+MzZGNywtQFdBRkxOUlNSMj5aYVpQYEpRUk//2wBDAQ4ODhMREyYVFSZPNS01T09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0//wAARCAAQABADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDGooorgPrj/9k=', 'base64');
const PORT = 3400 + Math.floor(Math.random() * 400);
const base = `http://127.0.0.1:${PORT}`;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ps-'));
const env = { ...process.env, PORT: String(PORT), DATA_DIR: path.join(tmp, 'data'), OUTPUT_DIR: path.join(tmp, 'out'), TEST_MODE: 'true',
  PIN: '4321', MAX_UPLOAD_MB: '1', MAX_COPIES: '20', TEST_PRINT_DELAY_MS: '400', UPLOAD_LIMIT_PER_MIN: '1000', RATE_LIMIT_PER_MIN: '5000' };

let pass = 0, fail = 0, child = null;
const ok = (c, name, extra = '') => { if (c) { pass++; console.log('  ok   ' + name); } else { fail++; console.log('  FAIL ' + name + ' ' + extra); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pdf = (t = 'hello') => Buffer.from(`%PDF-1.4\n1 0 obj<<>>endobj\n% ${t}\ntrailer<<>>\n%%EOF\n`);
function png() {
  const crc = (b) => zlib.crc32(b) >>> 0;
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(2, 0); ihdr.writeUInt32BE(2, 4); ihdr[8] = 8; ihdr[9] = 2;
  const rows = Buffer.concat([Buffer.from([0, 255, 0, 0, 0, 255, 0]), Buffer.from([0, 0, 0, 255, 255, 255, 0])]);
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(rows)), chunk('IEND', Buffer.alloc(0))]);
}
const docx = () => Buffer.concat([Buffer.from([0x50, 0x4b, 3, 4]), Buffer.alloc(30), Buffer.from('word/document.xml')]);

function upload(file, fields = {}, { name = 'a.pdf', pin = '4321', rawName } = {}) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.append(k, v);
  if (file) fd.append('file', new Blob([file]), rawName ?? name);
  return fetch(base + '/api/jobs', { method: 'POST', body: fd, headers: pin === null ? {} : { 'X-Pin': pin } }).then(async (r) => ({ status: r.status, body: await r.json().catch(() => ({})) }));
}
const get = (p, pin = '4321') => fetch(base + p, { headers: pin === null ? {} : { 'X-Pin': pin } }).then(async (r) => ({ status: r.status, body: await r.json().catch(() => ({})) }));
const post = (p, pin = '4321') => fetch(base + p, { method: 'POST', headers: { 'X-Pin': pin } }).then(async (r) => ({ status: r.status, body: await r.json().catch(() => ({})) }));
const jobs = async () => (await get('/api/state')).body.jobs;
async function waitFor(fn, ms = 8000) { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(50); } return false; }

function startServer() {
  return new Promise((resolve, reject) => {
    child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    let timer; child.stdout.on('data', (d) => { out += d; if (out.includes('http://') && !timer) timer = setTimeout(() => resolve(out), 250); });
    child.stderr.on('data', () => {});
    child.on('error', reject);
    setTimeout(() => reject(new Error('server did not start')), 8000);
  });
}
const stop = (sig = 'SIGKILL') => new Promise((r) => { child.once('exit', r); child.kill(sig); });

(async () => {
  const banner = await startServer();
  console.log('Basics');
  ok(banner.includes('http://'), 'prints an address on start');
  ok(!/no access PIN/.test(banner), 'no PIN warning when PIN is set');
  ok((await fetch(base + '/')).status === 200, 'page is served without PIN');
  ok((await get('/api/state', null)).status === 401, 'state needs PIN');
  ok((await get('/api/state', '0000')).status === 401, 'wrong PIN rejected');
  ok((await upload(pdf(), {}, { pin: null })).status === 401, 'upload without PIN rejected');
  ok((await post('/api/jobs/1/cancel', '9999')).status === 401, 'cancel without right PIN rejected');

  console.log('File types and sizes');
  let r = await upload(pdf(), { copies: '2', sides: 'long', color: 'bw', pages: '1-3,5', paper: 'Letter', orientation: 'landscape', name: 'Asha' });
  ok(r.status === 201, 'PDF accepted', JSON.stringify(r.body));
  r = await upload(png(), {}, { name: 'photo.png' }); ok(r.status === 201, 'PNG accepted');
  r = await upload(TINY_JPG, {}, { name: 'cam.jpg' }); ok(r.status === 201, 'JPG accepted');
  r = await upload(Buffer.from('MZ\x90\x00 evil exe'.padEnd(100, 'x')), {}, { name: 'invoice.pdf' });
  ok(r.status === 415 && /Unsupported file type/.test(r.body.error), 'renamed .exe called .pdf is rejected by content');
  r = await upload(pdf('renamed'), {}, { name: 'holiday.png' }); ok(r.status === 201, 'PDF renamed to .png is still treated as PDF');
  r = await upload(docx(), {}, { name: 'x.docx' }); ok(r.status === 415 || r.status === 201, 'DOCX handled (' + r.status + ': ' + (r.body.error || 'accepted') + ')');
  r = await upload(Buffer.concat([pdf(), Buffer.alloc(1.2 * 1024 * 1024)]));
  ok(r.status === 413 && /limit is 1 MB/.test(r.body.error), 'oversize file rejected cleanly: ' + r.body.error);
  r = await upload(null); ok(r.status === 400, 'no file gives a clear error: ' + r.body.error);
  r = await upload(Buffer.alloc(0)); ok(r.status === 400 || r.status === 415, 'empty file rejected');

  console.log('Options');
  for (const [bad, label] of [[{ copies: '0' }, 'copies 0'], [{ copies: '21' }, 'copies above MAX_COPIES'], [{ copies: '1.5' }, 'copies 1.5'], [{ pages: '3-1' }, 'pages 3-1'], [{ pages: '1;rm -rf /' }, 'pages with shell text'],
    [{ paper: 'A0' }, 'paper A0'], [{ sides: 'both' }, 'sides both'], [{ color: 'rainbow' }, 'colour rainbow'], [{ orientation: 'diagonal' }, 'orientation diagonal'], [{ name: 'x'.repeat(65) }, 'name of 65 chars']]) {
    const x = await upload(pdf(), bad); ok(x.status === 400 && x.body.error, 'rejects ' + label + ' -> ' + x.body.error);
  }
  r = await upload(png(), { pages: '2' }); ok(r.status === 400, 'page selection on a photo rejected');
  r = await upload(pdf(), { name: 'x'.repeat(64) }); ok(r.status === 201, 'name of exactly 64 chars accepted');

  console.log('Hostile file names');
  for (const n of ['../../x.pdf', 'a\r\nb.pdf', 'q"; rm -rf / ; ".pdf', 'C:\\Windows\\system32\\x.pdf', 'a'.repeat(300) + '.pdf', '$(calc).pdf']) {
    const x = await upload(pdf(), {}, { rawName: n.replace(/"/g, '%22') }); ok(x.status === 201, 'accepts safely: ' + JSON.stringify(n.slice(0, 24)));
  }
  const all = await jobs();
  ok(all.every((j) => !/[\r\n]/.test(j.name) && j.name.length <= 80 && !j.name.includes('/') ), 'stored display names are clean and short');
  ok(!fs.existsSync(path.join(tmp, 'x.pdf')) && !fs.existsSync(path.join(tmp, '..', 'x.pdf')), 'no file written outside the data folder');

  console.log('Queue');
  ok(await waitFor(async () => (await jobs()).every((j) => ['done', 'failed', 'cancelled'].includes(j.status)), 30000), 'all jobs finish');
  const done = (await jobs()).filter((j) => j.status === 'done').sort((a, b) => a.id - b.id);
  ok(done.length >= 10, 'jobs printed: ' + done.length);
  const outFiles = fs.readdirSync(path.join(tmp, 'out'));
  ok(outFiles.filter((f) => f.endsWith('.pdf')).length === done.length, 'one saved PDF per done job (no duplicates)');
  const firstOpt = JSON.parse(fs.readFileSync(path.join(tmp, 'out', 'job-00001.options.json'), 'utf8'));
  ok(firstOpt.options.copies === 2 && firstOpt.options.pages === '1-3,5' && firstOpt.printedBy === 'Asha', 'options saved next to the PDF');
  console.log('      Sumatra settings for job 1: ' + firstOpt.sumatraPrintSettings);
  ok(firstOpt.sumatraPrintSettings === '1-3,5,2x,duplexlong,monochrome,paper=letter,shrink,landscape', 'print settings string correct');
  const img = fs.readFileSync(path.join(tmp, 'out', 'job-00002.pdf')); ok(img.subarray(0, 5).toString() === '%PDF-', 'PNG was converted to a PDF');
  ok(fs.readFileSync(path.join(tmp, 'out', 'job-00003.pdf')).subarray(0, 5).toString() === '%PDF-', 'JPG was converted to a PDF');
  ok(fs.readdirSync(path.join(tmp, 'data', 'uploads')).length === 0, 'no uploaded documents left on disk after printing');

  console.log('Two people at once, in order, and cancel');
  const before = (await jobs()).length;
  const [a, b, c, d] = await Promise.all([1, 2, 3, 4].map((i) => upload(pdf('p' + i), { name: 'P' + i })));
  ok([a, b, c, d].every((x) => x.status === 201), 'four simultaneous uploads all accepted');
  const ids = [a, b, c, d].map((x) => x.body.job.id);
  ok(new Set(ids).size === 4, 'four different job ids');
  const cancelId = ids[3];
  const cr = await post('/api/jobs/' + cancelId + '/cancel'); ok(cr.status === 200, 'waiting job cancelled');
  ok((await post('/api/jobs/' + cancelId + '/cancel')).status === 409, 'cancelling twice gives a clear error');
  await waitFor(async () => (await jobs()).filter((j) => ids.includes(j.id)).every((j) => ['done', 'cancelled', 'failed'].includes(j.status)), 15000);
  const mine = (await jobs()).filter((j) => ids.includes(j.id)).sort((x, y) => x.id - y.id);
  ok(mine.slice(0, 3).every((j) => j.status === 'done') && mine[3].status === 'cancelled', 'three printed, cancelled one did not');
  ok(!fs.existsSync(path.join(tmp, 'out', 'job-' + String(cancelId).padStart(5, '0') + '.pdf')), 'cancelled job produced no output');
  const order = fs.readdirSync(path.join(tmp, 'out')).filter((f) => f.endsWith('.pdf')).map((f) => ({ f, t: fs.statSync(path.join(tmp, 'out', f)).mtimeMs }));
  const t = ids.slice(0, 3).map((id) => order.find((o) => o.f === 'job-' + String(id).padStart(5, '0') + '.pdf').t);
  ok(t[0] <= t[1] && t[1] <= t[2], 'printed in id (first-in-first-out) order');
  ok((await post('/api/jobs/999999/cancel')).status === 404, 'cancel unknown job gives 404');
  ok((await post('/api/jobs/' + ids[0] + '/cancel')).status === 409, 'cannot cancel a finished job');

  console.log('A failing job does not block the ones behind it');
  const bad = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.from('not really a png at all')]);
  const f1 = await upload(bad, {}, { name: 'broken.png' }); const f2 = await upload(pdf('after'), { name: 'After' });
  await waitFor(async () => (await jobs()).filter((j) => [f1.body.job.id, f2.body.job.id].includes(j.id)).every((j) => j.status !== 'waiting' && j.status !== 'printing'), 8000);
  const fj = (await jobs()).find((j) => j.id === f1.body.job.id), sj = (await jobs()).find((j) => j.id === f2.body.job.id);
  ok(fj.status === 'failed' && fj.reason, 'broken PNG marked failed with a reason: ' + fj.reason);
  ok(sj.status === 'done', 'job behind it still printed');

  console.log('Crash and restart');
  const q = []; for (let i = 0; i < 5; i++) q.push(await upload(pdf('crash' + i), { name: 'C' + i }));
  await waitFor(async () => (await jobs()).some((j) => j.status === 'printing'), 5000);
  const printingBefore = (await jobs()).find((j) => j.status === 'printing');
  await stop('SIGKILL');
  const printedBefore = new Set(fs.readdirSync(path.join(tmp, 'out')));
  const banner2 = await startServer();
  ok(/Restart recovery/.test(banner2), 'server restarted and reported what it recovered');
  await waitFor(async () => (await get('/api/state')).status === 200 && (await jobs()).every((j) => ['done', 'failed', 'cancelled'].includes(j.status)), 20000);
  const after = await jobs();
  const crashed = after.find((j) => j.id === printingBefore.id);
  ok(crashed.status === 'failed' && /may or may not have printed/.test(crashed.reason), 'job that was printing is marked failed (interrupted), not reprinted: ' + crashed.status);
  ok(!printedBefore.has('job-' + String(crashed.id).padStart(5, '0') + '.pdf') || fs.readdirSync(path.join(tmp, 'out')).filter((f) => f === 'job-' + String(crashed.id).padStart(5, '0') + '.pdf').length === 1, 'interrupted job not printed twice');
  const waitingIds = q.map((x) => x.body.job.id).filter((id) => id !== crashed.id);
  ok(waitingIds.every((id) => after.find((j) => j.id === id).status === 'done'), 'waiting jobs resumed and printed after restart');
  const pdfs = fs.readdirSync(path.join(tmp, 'out')).filter((f) => f.endsWith('.pdf'));
  ok(new Set(pdfs).size === pdfs.length && after.filter((j) => j.status === 'done').length === pdfs.length, 'saved PDFs match done jobs exactly (nothing printed twice)');
  ok(after.length > 20, 'history survived the restart (' + after.length + ' jobs)');
  ok(!after.some((j) => j.status === 'printing' || j.status === 'waiting'), 'nothing stuck on printing or waiting');
  ok(fs.readdirSync(path.join(tmp, 'data', 'uploads')).length === 0, 'no leftover uploads after restart');

  console.log('Abuse');
  const rr = await fetch(base + '/api/jobs', { method: 'POST', headers: { 'X-Pin': '4321', 'Content-Type': 'multipart/form-data; boundary=zzz' }, body: 'garbage' });
  ok(rr.status === 400, 'malformed multipart gives 400');
  const rj = await fetch(base + '/api/jobs', { method: 'POST', headers: { 'X-Pin': '4321', 'Content-Type': 'application/json' }, body: '{}' });
  ok(rj.status === 400, 'wrong content type gives 400');
  ok((await get('/api/nope')).status === 404 && (await fetch(base + '/../../etc/passwd')).status < 500, 'unknown paths are safe');
  ok((await get('/api/state')).status === 200, 'server still healthy after abuse');
  let lim = 0; for (let i = 0; i < 12; i++) { if ((await get('/api/state', 'bad' + i)).status === 429) lim++; }
  ok(lim > 0, 'repeated wrong PINs get blocked (429)');
  await stop('SIGTERM');

  console.log('Rate limit (separate server, low limit)');
  env.RATE_LIMIT_PER_MIN = '30'; env.PIN = ''; env.PORT = String(PORT + 1);
  const b3 = await startServer();
  ok(/no access PIN/.test(b3), 'warns clearly when no PIN is set');
  let blocked = 0; for (let i = 0; i < 80; i++) { const x = await fetch(`http://127.0.0.1:${PORT + 1}/api/state`); if (x.status === 429) blocked++; }
  ok(blocked > 30, 'flooding is slowed down: ' + blocked + ' of 80 requests got 429');
  await stop('SIGTERM');

  console.log(`\n${pass} passed, ${fail} failed`);
  fs.rmSync(tmp, { recursive: true, force: true });
  process.exit(fail ? 1 : 0);
})().catch(async (e) => { console.error('TEST ERROR', e); try { child && child.kill('SIGKILL'); } catch {} process.exit(1); });
