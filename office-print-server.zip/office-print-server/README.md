# Office Print

Open a web page on any phone or laptop on the office Wi-Fi, pick a file, tap **Print**, and it comes out of the USB printer.
Built for **Windows**. Zero npm packages: nothing to install except Node and SumatraPDF.

## Set up on the Windows host (once)

1. Install **Node.js 22.13 or newer** (https://nodejs.org).
2. Install **SumatraPDF** (https://www.sumatrapdfreader.org). The normal installer is fine.
3. Optional, only for Word files: install **LibreOffice**. Without it, DOCX is rejected with a clear message.
4. Copy `.env.example` to `.env`. Set at least `PIN=` (any number) and, if the right printer is not the Windows default, `PRINTER_NAME=` (exact name from Settings > Printers & scanners).
5. Start it with the one command: **`npm start`** (or double-click `start.bat`).
6. It prints addresses like `http://192.168.1.20:3000`. Type one into a phone browser. Windows may ask to allow Node through the firewall: allow it on **Private** networks.

**Try it without wasting paper:** set `TEST_MODE=true` in `.env`. Each job is saved to `output/` as `job-00001.pdf` plus `job-00001.options.json` (the options and the exact SumatraPDF settings that would be used).
To see waiting jobs and Cancel with one phone, add `TEST_PRINT_DELAY_MS=5000`.

**Start by itself:** open PowerShell **as Administrator** in this folder and run
`powershell -ExecutionPolicy Bypass -File .\install-autostart.ps1`
It starts the server when the user logs in and restarts it if it crashes. The host must be logged in (auto-login is the usual way for a shared office PC).

## Settings (environment variables or `.env`)

| Setting | Default | Meaning |
|---|---|---|
| `PORT` | 3000 | Web port |
| `PIN` | empty | Access PIN. If empty, a warning is printed at start |
| `PRINTER_NAME` | Windows default | Exact printer name |
| `TEST_MODE` | false on Windows | Save files instead of printing |
| `OUTPUT_DIR` | `output` | Where test mode saves files |
| `MAX_UPLOAD_MB` | 25 | File size limit |
| `MAX_COPIES` | 99 | Highest copies allowed (1 to 99) |
| `MAX_WAITING` | 50 | Jobs allowed to wait at once |
| `HISTORY_LIMIT` | 200 | Finished jobs kept in the list |
| `RATE_LIMIT_PER_MIN`, `UPLOAD_LIMIT_PER_MIN` | 240, 20 | Per device, per minute |
| `SUMATRA_PATH`, `SOFFICE_PATH` | auto | Only if installed in an unusual place |

## From tap to paper

1. The page uploads the file and options (`POST /api/jobs`) with the PIN in a header.
2. Server checks: rate limit, PIN, queue not full, size, **file type from the first bytes**, every option against fixed lists.
3. The file is saved under a random name (the user's file name is only kept as display text), and a row is written to SQLite as `waiting`.
4. One worker takes the oldest `waiting` job, marks it `printing`. Photos become a PDF (own code, honours phone rotation); DOCX becomes a PDF through LibreOffice.
5. The printer layer gets a PDF and the options. Test mode saves them. Windows mode runs `SumatraPDF -print-to <printer> -print-settings ...` with arguments as an array, no shell.
6. Job becomes `done` or `failed` (with a readable reason). The uploaded file is deleted either way. Next job starts.

Code map: `printers/` (test and Windows, chosen in `printers/index.js` only), `lib/queue.js`, `lib/store.js` (SQLite), `lib/imagepdf.js`, `lib/options.js`, `server.js`, `public/index.html`.

## The crashed job

If the server dies while a job is `printing`, on restart that job is marked **failed: "may or may not have printed"** and is **not** printed again. Why: we cannot know whether paper came out. A silent duplicate wastes paper and can print something twice by mistake (a payslip, say); a resend costs the person one tap, and the message tells them to check the printer first. Waiting jobs print as normal, history stays, nothing stays stuck on `printing`.

## Why build this? (and when not to)

Windows printer sharing, AirPrint/IPP or a cheap print-server box are the right answer if every device already prints through them: less to maintain, and they handle drivers properly. Do not build this in that case.
Build it when people have **no install and no setup** as a hard need (visitors, personal phones), when you want a **PIN, size and copy limits, one visible queue and history**, or when sharing is blocked by the printer's USB-only driver. The price: you own it. Updates, security fixes, and "it stopped working" calls are yours, and it knows less about the printer than the OS does (no real paper-out or job-progress feedback).

## Tested and not tested

Tested here (automated, `npm test`, 70 checks, test mode on Linux): upload of PDF/PNG/JPG, content-based type check, size limit, every option's validation, hostile file names, PIN and wrong PIN, rate limits, four simultaneous uploads, FIFO order, cancel, a failing job not blocking others, kill -9 mid-queue and restart, no leftover uploads. Photo to PDF checked against all 8 phone rotations and several PNG formats by rendering the PDFs.

**Not tested:** real printing, the SumatraPDF command on a real printer, PowerShell printer status on Windows, DOCX conversion with LibreOffice, Task Scheduler auto-start, the page on real phones. Test on the real host first. Known limits: no page-count check for PDF ranges (the printer ignores pages that do not exist), interlaced PNG and CMYK JPG are rejected with a message, HEIC photos are rejected (iPhones normally send JPG from the browser picker), job history is trimmed to the last 200, no HTTPS (anyone on the Wi-Fi can read traffic, including the PIN).
