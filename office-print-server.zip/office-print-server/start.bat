@echo off
cd /d "%~dp0"
echo Starting the office print server...
node server.js
echo.
echo The server stopped. Press any key to close.
pause >nul
