'use strict';
// Real printing on Windows: SumatraPDF command line + PowerShell for printer status.
// Every argument is passed as an array element. No shell ever sees user text.
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { PrintError } = require('../lib/errors');

const SIDES = { one: 'simplex', long: 'duplexlong', short: 'duplexshort' };
const PAPER = { A4: 'A4', Letter: 'letter', A3: 'A3', Legal: 'legal' };

// Options -> SumatraPDF -print-settings string. Values were validated against fixed lists first.
function buildSettings(o) {
  const p = [];
  if (o.pages) p.push(o.pages);
  if (o.copies > 1) p.push(`${o.copies}x`);
  p.push(SIDES[o.sides], o.color === 'bw' ? 'monochrome' : 'color', `paper=${PAPER[o.paper]}`, 'shrink');
  if (o.orientation !== 'auto') p.push(o.orientation);
  return p.join(',');
}

const PS = '$p = Get-CimInstance Win32_Printer | Where-Object { if ($env:PRINTER_NAME) { $_.Name -eq $env:PRINTER_NAME } else { $_.Default } } | Select-Object -First 1 Name,WorkOffline,PrinterStatus,DetectedErrorState; if ($p) { $p | ConvertTo-Json -Compress } else { "null" }';
const ERR_TEXT = { 4: 'Out of paper', 6: 'Out of toner', 7: 'Printer door is open', 8: 'Paper jam', 10: 'Printer needs service', 11: 'Output tray is full' };

function run(file, args, opts) {
  return new Promise((resolve, reject) => execFile(file, args, { windowsHide: true, ...opts }, (e, out, err) => (e ? reject(Object.assign(e, { stderr: err })) : resolve(out))));
}

function createWindowsPrinter(cfg) {
  let cache = { t: 0, v: null };

  function findSumatra() {
    const local = process.env.LOCALAPPDATA || '';
    return [cfg.sumatraPath, path.join(cfg.root, 'tools', 'SumatraPDF.exe'),
      'C:\\Program Files\\SumatraPDF\\SumatraPDF.exe', 'C:\\Program Files (x86)\\SumatraPDF\\SumatraPDF.exe',
      local && path.join(local, 'SumatraPDF', 'SumatraPDF.exe')].filter(Boolean).find((p) => fs.existsSync(p)) || null;
  }

  async function status(force = false) {
    if (!force && Date.now() - cache.t < 4000 && cache.v) return cache.v;
    let v;
    try {
      const out = (await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', PS],
        { timeout: 15000, env: { ...process.env, PRINTER_NAME: cfg.printerName } })).trim();
      const p = JSON.parse(out || 'null');
      if (!p) v = { state: 'offline', name: cfg.printerName, message: cfg.printerName ? `Printer "${cfg.printerName}" was not found` : 'No default printer is set on the host' };
      else if (p.WorkOffline || p.PrinterStatus === 7 || p.DetectedErrorState === 9) v = { state: 'offline', name: p.Name, message: 'Printer is offline. Check that it is switched on and connected.' };
      else if (ERR_TEXT[p.DetectedErrorState] || p.PrinterStatus === 6) v = { state: 'error', name: p.Name, message: ERR_TEXT[p.DetectedErrorState] || 'Printer has stopped' };
      else v = { state: 'ready', name: p.Name, message: p.PrinterStatus === 4 ? 'Printing' : 'Ready' };
    } catch {
      v = { state: 'error', name: cfg.printerName, message: 'Could not read the printer status' };
    }
    cache = { t: Date.now(), v };
    return v;
  }

  async function print({ file, options }) {
    const exe = findSumatra();
    if (!exe) throw new PrintError('SumatraPDF was not found on the host. Install it, or set SUMATRA_PATH.');
    const st = await status(true);
    if (st.state !== 'ready') throw new PrintError(st.message);
    const target = cfg.printerName || st.name;
    const args = [target ? '-print-to' : '-print-to-default'];
    if (target) args.push(target);
    args.push('-print-settings', buildSettings(options), '-silent', '-exit-when-done', file);
    try {
      await run(exe, args, { timeout: 120000 });
    } catch (e) {
      throw new PrintError(e.killed ? 'The printer did not respond within 2 minutes.' : `SumatraPDF could not print this file (exit code ${e.code ?? 'unknown'}).`);
    }
  }

  return { name: 'Windows printer (SumatraPDF)', status, print, warnings: () => (findSumatra() ? [] : ['SumatraPDF was not found. Install it or set SUMATRA_PATH, or printing will fail.']) };
}
module.exports = { createWindowsPrinter, buildSettings };
