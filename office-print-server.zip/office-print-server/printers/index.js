'use strict';
// The only place that decides test mode vs real printing. The web code just calls printer.print() and printer.status().
const { createTestPrinter } = require('./test');
const { createWindowsPrinter } = require('./windows');

function createPrinter(cfg) {
  if (cfg.testMode) return createTestPrinter(cfg);
  if (process.platform !== 'win32') throw new Error('Real printing is built for Windows. Set TEST_MODE=true on this system.');
  return createWindowsPrinter(cfg);
}
module.exports = { createPrinter };
