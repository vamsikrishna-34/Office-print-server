'use strict';
// Test mode: nothing is printed. The exact PDF that would go to the printer is saved with the chosen options.
const fsp = require('fs/promises');
const path = require('path');
const { buildSettings } = require('./windows');

function createTestPrinter(cfg) {
  return {
    name: 'Test mode (saves files, prints nothing)',
    async status() { return { state: 'ready', name: 'Test printer', message: 'Test mode: jobs are saved, not printed' }; },
    async print({ file, options, jobId, displayName, owner }) {
      if (cfg.testPrintDelayMs) await new Promise((r) => setTimeout(r, cfg.testPrintDelayMs));
      await fsp.mkdir(cfg.outputDir, { recursive: true });
      const base = path.join(cfg.outputDir, `job-${String(jobId).padStart(5, '0')}`);
      await fsp.copyFile(file, `${base}.pdf`);
      await fsp.writeFile(`${base}.options.json`, JSON.stringify({
        jobId, savedAt: new Date().toISOString(), uploadedFileName: displayName, printedBy: owner || null,
        options, sumatraPrintSettings: buildSettings(options),
      }, null, 2));
    },
    warnings: () => [],
  };
}
module.exports = { createTestPrinter };
